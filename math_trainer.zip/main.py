import sys
import pandas as pd
from math import *
from PyQt6 import QtWidgets, uic



class Random:
    """Класс для генерации псевдослучайных чисел"""

    def __init__(self, seed=42):
        """
        Устанавливаем начальное значение
        """
        self.seed = seed

    def next(self):
        """Метод для получения следующего случайного числа."""
        a = 1664525
        c = 1013904224
        m = 2 ** 32
        self.seed = (a * self.seed + c) % m
        return self.seed

    def randint(self, min_val, max_val):
        """Метод для получения случайного целого числа в заданном диапазоне."""
        return min_val + self.next() % (max_val - min_val + 1)

class MathTrainer:
    """Класс для генерации вопросов и проверки ответов от пользователя."""

    def __init__(self):
        """
        Инициализация нужных переменных - правильные и неправильные ответы, список попыток, нужные операнты
        """
        self.operations = {
            '+': self.add,
            '-': self.subtract,
            '*': self.multiply,
            '/': self.divide,
            '√': self.sqrt,
            '**': self.step,
            'log': self.log,
            'sin':self.sin,
            'cos':self.cos

        }
        self.current_answer = 0
        self.correct_answers = 0
        self.incorrect_answers = 0
        self.random_generator = Random()
        self.attempts_log = []

    def __str__(self):
        """Возвращает строковое представление текущей статистики."""
        return (f"Правильные ответы: {self.correct_answers}, "
                f"Неправильные ответы: {self.incorrect_answers}, "
                f"Всего попыток: {len(self.attempts_log)}")

    def __len__(self):
        """Возвращает количество попыток."""
        return len(self.attempts_log)

    def __getitem__(self, index):
        """Позволяет обращаться к логам попыток по индексу."""
        return self.attempts_log[index]

    def add(self, a, b):
        """Функция для сложения двух чисел."""
        return a + b

    def subtract(self, a, b):
        """Функция для вычитания двух чисел."""
        return a - b

    def multiply(self, a, b):
        """Функция для умножения двух чисел."""
        return a * b

    def divide(self, a, b):
        """
        Функция для деления двух чисел.
        Делаем проверку по делению на ноль.
        """
        return a / b if b != 0 else 0

    def sqrt(self, a):
        """
        Функция для нахождения корня числа.
        """
        return sqrt(a) if a >= 0 else 0

    def step(self, a, b):
        """
        Функция для возведения числа в степень.
        """
        return a ** b

    def log(self, a, b):
        """
        Функция для нахождения логарифма числа a по основанию b.
        """
        return log(a, b) if a > 0 and b != 1 and b > 0 else 0

    def sin(self, a):
        """
        Функция для нахождения синуса числа.
        """
        return sin(a)

    def cos(self,a):
        """
        Функция для нахождения косинуса числа
        """
        return cos(a)

    def generate_question(self, difficulty):
        """Создание вопросов по уровню сложности."""
        if difficulty == "Легкий":

            #Придание значений переменным
            n1 = self.random_generator.randint(10, 40)
            n2 = self.random_generator.randint(10, n1)  # n2 всегда меньше или равно n1
            n3 = self.random_generator.randint(10, 45)
            n4_base = self.random_generator.randint(3, 18)
            n4 = n4_base ** 2
            n5 = self.random_generator.randint(10, 35)
            n6_base = self.random_generator.randint(3, 25)
            n6 = n6_base ** 2
            n7 = self.random_generator.randint(10, 40)

            # Инициализация возможных операндов для каждой операции
            operant1 = self.random_generator.randint(1, 1)  # вычитание
            operant2 = self.random_generator.randint(2, 3)  # умножение или деление
            operant3 = self.random_generator.randint(2, 3)  # умножение или деление
            operant4 = self.random_generator.randint(0, 1)  # сложение или вычитание
            operant5 = self.random_generator.randint(2, 3)  # умножение или деление
            operant6 = self.random_generator.randint(1, 1)  # вычитание

            #Проверяем, что при делении получается целое число
            if operant2 == 3:
                while n2 % n3 != 0:
                    n3 = self.random_generator.randint(10, 30)

            if operant5 == 3:
                while n6_base % n1 != 0:
                    n1 = self.random_generator.randint(10, 25)

            #Создание операций
            operation1 = list(self.operations.keys())[operant1]
            operation2 = list(self.operations.keys())[operant2]
            operation3 = list(self.operations.keys())[operant3]
            operation4 = list(self.operations.keys())[operant4]
            operation5 = list(self.operations.keys())[operant5]
            operation6 = list(self.operations.keys())[operant6]

            # Формирование вопроса
            question = f"(√{n6} {operation5} {n1} {operation1} {n2} {operation2} {n3} {operation4} {n5}) {operation3} √{n4} {operation6} {n7}"
            question_2 = f"({sqrt(n6)} {operation5} {n1} {operation1} {n2} {operation2} {n3} {operation4} {n5}) {operation3} {sqrt(n4)} {operation6} {n7}"

            # Вычисление ответа
            self.current_answer = eval(question_2)
            question_label.setText(f"{question} = ")
            feedback_label.setText("")
            answer_input.clear()


        elif difficulty == "Средний":

            #Придание значений переменным
            n1 = self.random_generator.randint(100, 300)
            n2 = self.random_generator.randint(4, 10)
            n3 = self.random_generator.randint(0, 3)
            n4_base = self.random_generator.randint(11, 22)
            n4 = n4_base ** 2
            n5 = self.random_generator.randint(4, 10)
            n6 = self.random_generator.randint(0, 3)
            n7 = self.random_generator.randint(5, 30)
            n8_base = self.random_generator.randint(11, 22)
            n8 = n8_base ** 2
            n9 = self.random_generator.randint(100, 900)

            # Инициализация возможных операндов для каждой операции
            operant1 = self.random_generator.randint(2, 2)  # умножение
            operant2 = self.random_generator.randint(5, 5)  # возведение в степень
            operant3 = self.random_generator.randint(0, 1)  # сложение или вычитание
            operant4 = self.random_generator.randint(1, 1)  # вычитание
            operant5 = self.random_generator.randint(5, 5)  # возведение в степень
            operant6 = self.random_generator.randint(0, 1)  # сложение или вычитание
            operant7 = self.random_generator.randint(3, 3)  # деление
            operant8 = self.random_generator.randint(0, 1)  # сложение или вычитание

            #Создание операций
            operation1 = list(self.operations.keys())[operant1]
            operation2 = list(self.operations.keys())[operant2]
            operation3 = list(self.operations.keys())[operant3]
            operation4 = list(self.operations.keys())[operant4]
            operation5 = list(self.operations.keys())[operant5]
            operation6 = list(self.operations.keys())[operant6]
            operation7 = list(self.operations.keys())[operant7]
            operation8 = list(self.operations.keys())[operant8]

            #Формирование вопроса
            question = f"({n1} {operation1} ({n2} {operation2} {n3}) {operation3} √{n4} {operation4} ({n5} {operation5} {n6}) {operation6} {n7}) {operation7} (√{n8} {operation8} {n9})"
            question_2 = f"({n1} {operation1} ({n2} {operation2} {n3}) {operation3} {sqrt(n4)} {operation4} ({n5} {operation5} {n6}) {operation6} {n7}) {operation7} ({sqrt(n8)} {operation8} {n9})"

            # Вычисление ответа
            self.current_answer = round(eval(question_2), 2)
            question_label.setText(f"{question} = ")
            feedback_label.setText("")
            answer_input.clear()


        else:

            # Придание значений переменным
            n1 = self.random_generator.randint(5, 13)
            n2 = self.random_generator.randint(2, 3)  # n2 всегда меньше или равно n1
            n3_base = self.random_generator.randint(2, 5)
            n4 = self.random_generator.randint(5, 9)
            n3 = n4 ** n3_base
            n5_base = self.random_generator.randint(2, 5)
            n7 = self.random_generator.randint(5, 9)
            n5 = n7 ** n5_base
            n6_base = self.random_generator.randint(3, 25)
            n6 = n6_base ** 2
            n8 = self.random_generator.randint(100, 900)

            sin_table = [0, 30, 90, 150, 180, 270]  # список возможных значений для синуса
            cos_table = [0, 60, 90, 120, 180, 270]  # список возможных значений для косинуса

            n9_base = self.random_generator.randint(0,5)
            n9 = list(sin_table)[n9_base]

            n10_base = self.random_generator.randint(0, 5)
            n10 = list(cos_table)[n10_base]

            #Инициализация возможных операндов для каждой операции
            operant1 = self.random_generator.randint(5, 5)  # возведение в степень
            operant2 = self.random_generator.randint(2, 2)  # умножение
            operant3 = self.random_generator.randint(1, 1)  # вычитание
            operant4 = self.random_generator.randint(3, 3)  # деление
            operant5 = self.random_generator.randint(1, 1)  # вычитание
            operant6 = self.random_generator.randint(2, 2)  # умножение
            operant7 = self.random_generator.randint(0, 0)  # сложение

            #Проверяем, что при делении получается целое число
            if operant4 == 3:
                while n6_base % log(n5, n7) != 0:
                    n6_base = self.random_generator.randint(3, 25)

            #Создание операций
            operation1 = list(self.operations.keys())[operant1]
            operation2 = list(self.operations.keys())[operant2]
            operation3 = list(self.operations.keys())[operant3]
            operation4 = list(self.operations.keys())[operant4]
            operation5 = list(self.operations.keys())[operant5]
            operation6 = list(self.operations.keys())[operant6]
            operation7 = list(self.operations.keys())[operant7]

            # Формирование вопроса
            question = f"({n1} {operation1} {n2}) {operation2} cos({n10}) {operation7} log{n4}({n3}) {operation3} √{n6} {operation4} log{n7}({n5}) {operation5} {n8} {operation6} sin({n9})"
            question_2 = f"({n1} {operation1} {n2}) {operation2} {round(cos(radians(n10)), 1)} {operation7} {log(n3, n4)} {operation3} {sqrt(n6)} {operation4} {log(n5, n7)} {operation5} {n8} {operation6} {round(sin(radians(n9)), 1)}"

            # Вычисление ответа
            self.current_answer = (eval(question_2))
            question_label.setText(f"{question} = ")
            feedback_label.setText("")
            answer_input.clear()

    def check_answer(self):
        """Проверка ответа пользователя."""
        user_answer = answer_input.text()
        try:
            user_answer = float(user_answer)
            correct = user_answer == self.current_answer
            if correct:
                self.correct_answers += 1
            else:
                self.incorrect_answers += 1

            self.log_attempt(user_answer, correct)

            self.update_statistics()
            difficulty = difficulty_combo_box.currentText()
            self.generate_question(difficulty)
        except ValueError:
            feedback_label.setText("Введите корректный ответ!")

    def log_attempt(self, user_answer, correct):
        """Записывает информацию от пользователя."""
        self.attempts_log.append({
            "Вопрос": question_label.text(),
            "Ответ пользователя": user_answer,
            "Правильный ответ": self.current_answer,
            "Результат": "Правильно" if correct else "Неправильно"
        })

    def update_statistics(self):
        """
        Обновление статистики. Вывод количества правильных и неправильных ответов.
        """
        stats_label.setText(str(self))

    def reset_statistics(self):
        """Сбрасывание статистику. Обнуление значений."""
        self.correct_answers = 0
        self.incorrect_answers = 0
        self.attempts_log = []
        self.update_statistics()

    def save_statistics(self):
        """
        Сохранение статистики в файле.
        """
        if self.attempts_log:
            df = pd.DataFrame(self.attempts_log)
            df.to_csv("res.csv", index=False, encoding="utf-8", sep=';')
            feedback_label.setText("Статистика сохранена в res.csv!")
        else:
            feedback_label.setText("Нет данных для сохранения!")




app = QtWidgets.QApplication(sys.argv)
window = uic.loadUi('math_trainer.ui')

def go_to_main_page():
    """Переключается между страницами интерфейса."""
    window.stackedWidget.setCurrentIndex(1)

trainer = MathTrainer()
window.pushButton_start.clicked.connect(go_to_main_page)
window.pushButton.clicked.connect(trainer.check_answer)
window.comboBox.currentIndexChanged.connect(lambda: trainer.generate_question(window.comboBox.currentText()))
window.pushButton_reset.clicked.connect(trainer.reset_statistics)
window.pushButton_save.clicked.connect(trainer.save_statistics)

question_label = window.question_label
feedback_label = window.feedback_label
answer_input = window.answer
stats_label = window.stats
difficulty_combo_box = window.comboBox

trainer.generate_question("Легкий")

window.show()
sys.exit(app.exec())
